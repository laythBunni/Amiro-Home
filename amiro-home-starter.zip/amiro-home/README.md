# Amiro Home

This is a mobile-first AI assistant app scaffold for families.

## Structure
- `client/` - React frontend placeholder
- `server/` - Node.js backend placeholder
